import React, { useState } from "react";
import useBasketStore from "../store/basketStore";
import { Counter } from "../components/Counter";
import $host from "../api";
function Basket() {
    const [name, setName] = useState("");
    const [phone, setPhone] = useState("");
    const [email, setEmail] = useState("");

    const basket = useBasketStore((state) => state.basket);
    const removeProduct = useBasketStore((state) => state.removeProduct);
    const deleteAll = useBasketStore((state) => state.deleteAll);

    const productsRows = basket.map((pr) => (
        <tr key={pr.id}>
            <td className="first__td">
                <img src={pr.photo} height={40}></img>
                {pr.name}
            </td>
            <td>{pr.price}</td>
            <td>
                <Counter max={pr.amount} current={pr.cnt} id={pr.id} />
            </td>
            <td>{pr.price * pr.cnt}</td>
            <td>
                <button
                    className="basket__delete"
                    onClick={() => removeProduct(pr.id)}
                >
                    <span class="material-symbols-outlined">close</span>
                </button>
            </td>
        </tr>
    ));

    return (
        <div style={{ minHeight: "80vh" }} className="_container">
            <table>
                <thead>
                    <tr>
                        <td className="first__td">Product</td>
                        <td>Price / $</td>
                        <td>Quantity</td>
                        <td>Total price / $</td>
                        <td>Delete</td>
                    </tr>
                </thead>
                <tbody>{productsRows}</tbody>
            </table>
            <div className="basket__total">
                <strong style={{ marginRight: 30 }}>Total:</strong>
                <strong>
                    {basket.reduce((summ, elem) => {
                        return summ + elem.cnt * elem.price;
                    }, 0)}
                    $
                </strong>
            </div>
            <div className="basket__inputs">
                <input
                    className="basket__input"
                    placeholder="Enter your name"
                    type="text"
                    onChange={(e) => setName(e.target.value)}
                />
                <input
                    className="basket__input"
                    placeholder="Enter phone number"
                    type="text"
                    onChange={(e) => setPhone(e.target.value)}
                />
                <input
                    className="basket__input"
                    placeholder="Enter your e-mail"
                    type="email"
                    onChange={(e) => setEmail(e.target.value)}
                />
            </div>
            <div className="basket__warn" id="basket__warn1">
                <span>Fill the input fields</span>
            </div>
            <div className="basket__succes" id="basket__succes1">
                <span>Order created</span>
            </div>
            {basket.length ? (
                <button
                    className="basket__makeorder"
                    onClick={() => {
                        if (name !== "" && phone !== "" && email !== "") {
                            // async (id) => {
                            //     $host.post(`/order/`, {
                            //         {
                            //             name: name,
                            //             email: email,
                            //             phone: phone,
                            //             "order_item": [
                            //         {"product":1, "amount":5 }
                            //         ]
                            //         }
                            //     })
                            deleteAll();
                            [
                                ...document.getElementsByClassName(
                                    "basket__input"
                                ),
                            ].forEach((elem) => {
                                elem.value = "";
                            });
                            setName("");
                            setPhone("");
                            setEmail("");
                            document
                                .getElementById("basket__succes1")
                                .classList.add("active1");
                            setTimeout(() => {
                                document
                                    .getElementById("basket__succes1")
                                    .classList.remove("active1");
                            }, 2000);
                        } else {
                            document
                                .getElementById("basket__warn1")
                                .classList.add("active1");
                            setTimeout(() => {
                                document
                                    .getElementById("basket__warn1")
                                    .classList.remove("active1");
                            }, 2000);
                        }
                    }}
                >
                    Make order
                </button>
            ) : null}
        </div>
    );
}

export default Basket;
