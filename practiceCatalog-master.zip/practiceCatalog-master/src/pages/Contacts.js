import React from "react";
import {
    GoogleMap,
    useLoadScript,
    Marker,
    InfoWindow,
} from "@react-google-maps/api";
import "../styles/style.scss";
import ErrorPage from "./ErrorPage";

const centerKyiv = { lat: 50.504513119768255, lng: 30.423204168308736 };

function contacts() {
    const { isLoaded, loadError } = useLoadScript({
        googleMapsApiKey: process.env.REACT_API_KEY,
        language: "uk",
    });

    if (!isLoaded)
        return (
            <div>
                <div className="lds-ring">
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                </div>
            </div>
        );

    if (loadError)
        return (
            <ErrorPage
                title={"Помилка при завантаженні GoogleMaps"}
                text={"Головне меню"}
                link={"/"}
            />
        );

    return (
        <div className="contacts _container">
            <div className="contacts__block">
                <div className="contacts__text">
                    <h1>Болото Шрека:</h1>
                    магазин "Квіти від Текіса"
                    <br />
                    м.Київ, проспект Правди, 35
                    <br />
                    Тел: +380677777777
                    <br />
                    e-mail: yarmolochkin@ukr.net
                </div>
                <div className="contacts__map">
                    <Map
                        center={centerKyiv}
                        lat={50.500513119768255}
                        lng={30.423204168308736}
                        description=" м.Київ, проспект Правди, 35"
                    />
                </div>
            </div>
        </div>
    );
}
function Map({ center, lat, lng, description }) {
    return (
        <GoogleMap
            options={{
                streetViewControl: false,
                scaleControl: false,
                mapTypeControl: false,
                myLocationButtonEnabled: false,
                zoomControl: false,
                fullscreenControl: false,
            }}
            zoom={13}
            center={center}
            mapContainerClassName="map"
        >
            <Marker position={{ lat: lat, lng: lng }} />
            <InfoWindow position={center}>
                <p className="tc">{description}</p>
            </InfoWindow>
        </GoogleMap>
    );
}

export default contacts;
