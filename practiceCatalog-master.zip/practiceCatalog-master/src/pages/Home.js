import React from "react";
import Slider from "../components/Slider";
export default function Home() {
    return (
        <div>
            <Slider />
            <div class="row _container">
                <div class="col-md-3 box-left">
                    <h3 class="h3-banner-text">
                        Plants new Arrivals
                        <br />
                        <span class="highlight">Get upto 25% Off!</span>
                    </h3>
                </div>
                <div class="col-md-3 box-left-middle">
                    <h3 class="h3-banner-text">
                        Wedding Flowers
                        <br />
                        <span class="highlight">Get upto 25% Off!</span>
                    </h3>
                </div>
                <div class="col-md-3 box-middle">
                    <div class="wrap-outline">
                        <h3 class="h3-banner-text">
                            Romance Bouquets <br />
                            <span class="highlight">Get upto 25% Off!</span>
                        </h3>
                    </div>
                </div>
                <div class="col-md-3 box-right">
                    <h3 class="h3-banner-text">
                        Valentine's Day Flowers
                        <br />
                        <span class="highlight">Get upto 25% Off!</span>
                    </h3>
                </div>
            </div>
        </div>
    );
}
